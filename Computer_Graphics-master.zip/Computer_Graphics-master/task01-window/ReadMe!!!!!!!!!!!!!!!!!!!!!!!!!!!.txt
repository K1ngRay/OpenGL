﻿请用CMake工具打开该工程，具体方法是：
1- 在该文件夹内新建一个build文件夹。
2- 在cmake的源码路径处填入该文件夹的路径。
3- 在cmake的编译输出路径处填入build的路径。
4- 同编译GLFW的方法一样，configure两次再generate（注意选择适合自己的IDE版本）
5- 打开build中编译好的文件，即可。（如，选择VS则打开*.sln）
note:
编译目录不要有特殊字符。