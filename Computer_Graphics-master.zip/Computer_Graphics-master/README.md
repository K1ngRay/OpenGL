## 计算机图形学配套实验
 ![](https://img.shields.io/badge/release-v1.0-yellowgreen.svg) ![](https://img.shields.io/badge/platform-windows-brightgreen.svg) ![](https://img.shields.io/badge/build-cmake-blue.svg)

### 原课程链接
[中国大学Mooc视频课程--计算机图形学[万琳]](http://163.lu/klf3s0)

### 目前上线实验

* 实验一：绘制窗体
* 实验二：绘制三角形
* 实验三：绘制四边形
* 实验四：绘制球
* 实验五：绘制模型
* 实验六：旋转立方体
* 实验七：摄像机
* 实验八：Phong光照
* 实验九：天空盒
* 实验十：法线贴图
* 实验十一：阴影
* 实验十二：混合
* 实验十三：延迟渲染
* 实验十四：粒子

### 计算机图形学课程及实验勘误
>各位同学，如果您在学习过程中发现任何错误，包括慕课的课程中或是实验中，例如某个重要概念的理解及描述错误等，请至本项目下提交一个Issues，您的反馈可能会对计算机图形学课程的质量有着较大帮助。非常感谢您的宝贵时间及支持！
---
**Enjoy~**
